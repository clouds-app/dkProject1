<template>
  <div class="modal fade" id="modal-form">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body wrapper-lg">
          <div class="row">
            <div class="col-sm-6 b-r">
              <h3 class="m-t-none m-b">登录/注册</h3>
              <p>定制音乐频道</p>
              <form role="form">
                <div class="form-group">
                  <label>名称</label>
                  <input type="text" class="form-control" placeholder="店铺名称或编码" />
                </div>
                <div class="form-group">
                  <label>激活码</label>
                  <input type="text" class="form-control" placeholder="激活码" />
                </div>
                <div class="checkbox m-t-lg">
                  <button type="button" @click="login" class="btn btn-sm btn-success pull-right text-uc m-t-n-xs"><strong>确认</strong></button>
                  <label> <input type="checkbox" /> 记住我 </label>
                </div>
              </form>
            </div>
            <div class="col-sm-6">
              <h4>Not a member?</h4>
              <p>You can create an account <a href="#" class="text-info">here</a></p>
              <p>OR</p>
              <a href="#" class="btn btn-primary btn-block m-b-sm"><i class="fa fa-facebook pull-left"></i>Sign in with Facebook</a>
              <a href="#" class="btn btn-info btn-block m-b-sm"><i class="fa fa-twitter pull-left"></i>Sign in with Twitter</a>
              <a href="#" class="btn btn-danger btn-block"><i class="fa fa-google-plus pull-left"></i>Sign in with Google+</a>
            </div>
          </div>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
</template>

<script>
   import api from '../../service/api'
    export default {
        name: "login-content",
      methods:{
          login:function () {
            debugger
            let szIP = "172.16.144.204";
            let  szMac = '61a8babe3aaba8c58f801a13451be781';
            let szShopName = '1121';
            let szActivationCode = 'f593b80124c4bfca';
            api.login(szIP, szMac, szShopName, szActivationCode);
          }
      }
    }
</script>

<style scoped>

</style>
