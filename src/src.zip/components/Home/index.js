import FooterView from  '@/FooterView.vue'
export default {
  FooterView
}
